"""
Virtual self-balancing car (inverted pendulum on wheels) controlled by a PID loop.
Simplified model: theta'' = (g*sin(theta) - a*cos(theta) + d) / L
  theta : lean angle (rad, + = leaning forward)
  a     : wheel (cart) acceleration commanded by the controller
  d     : constant disturbance (uneven weight / push)
Includes: motor limit, motor lag, 100 Hz control loop, sensor noise.
Run:  python balancing_car_pid_sim.py
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

G, L = 9.81, 0.10            # gravity, height of centre of mass (m)
A_MAX = 8.0                  # max wheel acceleration (m/s^2)  (motor limit)
TAU = 0.02                   # motor lag (s)
DT, CTRL_DT = 0.001, 0.01    # physics step, controller step (100 Hz)
NOISE_DEG = 0.2              # sensor noise (deg)
FALL_DEG = 45                # considered "fallen" beyond this

def simulate(Kp, Ki, Kd, T=6.0, theta0_deg=5.0, push_t=3.0, push_w=0.8,
             disturbance=0.0, seed=1):
    rng = np.random.default_rng(seed)
    n = int(T / DT)
    th, w, x, v, a_act = np.radians(theta0_deg), 0.0, 0.0, 0.0, 0.0
    integ, prev_meas, u = 0.0, th, 0.0
    log = np.zeros((n, 5)); fell_at = None
    for i in range(n):
        t = i * DT
        if abs(t - push_t) < DT / 2:                 # sudden push
            w += push_w
        if i % int(CTRL_DT / DT) == 0:               # controller runs at 100 Hz
            meas = th + np.radians(rng.normal(0, NOISE_DEG))
            err = 0.0 - meas                         # setpoint = upright
            integ = np.clip(integ + err * CTRL_DT, -0.5, 0.5)
            deriv = -(meas - prev_meas) / CTRL_DT    # d(error)/dt = -d(meas)/dt
            prev_meas = meas
            # lean forward (+) -> accelerate forward (+): command = -(PID of error)
            u = -(Kp * err + Ki * integ + Kd * deriv)
            u = float(np.clip(u, -A_MAX, A_MAX))
        a_act += (u - a_act) / TAU * DT              # motor lag
        alpha = (G * np.sin(th) - a_act * np.cos(th) + disturbance) / L
        w += alpha * DT; th += w * DT
        v += a_act * DT; x += v * DT
        log[i] = (t, np.degrees(th), u, x, v)
        if abs(np.degrees(th)) > FALL_DEG and fell_at is None:
            fell_at = t; log = log[:i + 1]; break
    return log, fell_at

def metrics(log, fell_at, push_t=3.0):
    t, th = log[:, 0], log[:, 1]
    if fell_at is not None:
        return dict(result=f"FELL at {fell_at:.2f} s", peak_after_push="-", settle="-", rms="-", drift="-")
    post = t > push_t
    peak = np.max(np.abs(th[post]))
    within = np.abs(th) < 1.0
    settle = "-"
    idx = np.where(post & ~within)[0]
    settle = f"{t[idx[-1]] - push_t:.2f} s" if len(idx) else "0.00 s"
    if len(idx) and t[idx[-1]] > t[-1] - 0.05: settle = "not settled"
    rms = np.sqrt(np.mean(th[t > 4.5] ** 2))
    return dict(result="Balanced", peak_after_push=f"{peak:.1f} deg", settle=settle,
                rms=f"{rms:.2f} deg", drift=f"{log[-1,3]:.2f} m")

def run_group(name, configs, **kw):
    fig, ax = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    print(f"\n=== {name} ===")
    print(f"{'Kp':>6} {'Ki':>6} {'Kd':>6} | {'result':<18} {'peak after push':<16} {'settle':<12} {'RMS 4.5-6s':<11} {'cart drift'}")
    for (Kp, Ki, Kd) in configs:
        log, fell = simulate(Kp, Ki, Kd, **kw); m = metrics(log, fell)
        print(f"{Kp:6g} {Ki:6g} {Kd:6g} | {m['result']:<18} {m['peak_after_push']:<16} {m['settle']:<12} {m['rms']:<11} {m['drift']}")
        lab = f"Kp={Kp:g}, Ki={Ki:g}, Kd={Kd:g}"
        ax[0].plot(log[:, 0], log[:, 1], label=lab); ax[1].plot(log[:, 0], log[:, 2])
    ax[0].axhline(0, color="k", lw=.5); ax[0].set_ylim(-30, 30)
    ax[0].set_ylabel("Tilt angle (deg)"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3)
    ax[0].set_title(name + "  (push at t = 3 s)")
    ax[1].set_ylabel("Motor command (m/s²)"); ax[1].set_xlabel("Time (s)"); ax[1].grid(alpha=.3)
    fig.tight_layout(); fig.savefig(name.split(":")[0].replace(" ", "_") + ".png", dpi=130); plt.close(fig)

if __name__ == "__main__":
    # Experiment 1: change P only (I = D = 0)
    run_group("Exp1: effect of P (Ki=0, Kd=0)", [(5,0,0), (15,0,0), (30,0,0), (80,0,0)])
    # Experiment 2: P fixed, change D
    run_group("Exp2: effect of D (Kp=30, Ki=0)", [(30,0,0), (30,0,0.5), (30,0,1.5), (30,0,6)])
    # Experiment 3: P and D fixed, change I, with a constant disturbance (uneven weight)
    run_group("Exp3: effect of I (Kp=30, Kd=1.5, constant lean disturbance)",
              [(30,0,1.5), (30,20,1.5), (30,100,1.5), (30,400,1.5)], disturbance=1.0)
    # Final tuned
    run_group("Final: tuned controller", [(30, 20, 1.5)])
